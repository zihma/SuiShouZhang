"""Build the bundled Android app with local JDK / Android SDK tools."""
from pathlib import Path
import os
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'android'
BUILD = ROOT / 'build'
EXE = '.exe' if os.name == 'nt' else ''

def require_env(*names):
    for name in names:
        if os.environ.get(name):
            return Path(os.environ[name]).expanduser().resolve()
    raise SystemExit('Set ' + ' or '.join(names) + ' before building.')

JAVA = require_env('JAVA_HOME') / 'bin'
SDK = require_env('ANDROID_HOME', 'ANDROID_SDK_ROOT')
def version(path):
    return tuple(int(n) if n.isdigit() else 0 for n in path.name.replace('android-', '').split('.'))
tools = sorted((SDK / 'build-tools').glob('*'), key=version, reverse=True)
platforms = sorted((SDK / 'platforms').glob('android-*'), key=version, reverse=True)
BT = next((p for p in tools if (p / ('aapt2' + EXE)).is_file() and (p / 'lib/d8.jar').is_file()), None)
PLATFORM = next((p / 'android.jar' for p in platforms if version(p) >= (29,) and (p / 'android.jar').is_file()), None)
if BT is None or PLATFORM is None:
    raise SystemExit('Install Android SDK Build Tools and an Android platform API 29 or later.')
for name in ['classes', 'dex', 'signing']:
    (BUILD / name).mkdir(parents=True, exist_ok=True)

def run(args):
    result = subprocess.run([str(x) for x in args], cwd=ROOT)
    if result.returncode:
        raise SystemExit(result.returncode)

run([BT / ('aapt2'+EXE), 'compile', '--dir', APP/'res', '-o', BUILD/'resources.zip'])
run([BT / ('aapt2'+EXE), 'link', '-o', BUILD/'base.apk', '-I', PLATFORM,
     '--manifest', APP/'AndroidManifest.xml', '--min-sdk-version', '26',
     '--target-sdk-version', '35', BUILD/'resources.zip'])
run([JAVA/('javac'+EXE), '-encoding', 'UTF-8', '--release', '8', '-classpath', PLATFORM,
     '-d', BUILD/'classes', *sorted((APP/'src').rglob('*.java'))])
run([JAVA/('java'+EXE), '-cp', BT/'lib/d8.jar', 'com.android.tools.r8.D8', '--release',
     '--min-api', '26', '--lib', PLATFORM, '--output', BUILD/'dex',
     *sorted((BUILD/'classes').rglob('*.class'))])
with zipfile.ZipFile(BUILD/'base.apk', 'a', compression=zipfile.ZIP_DEFLATED) as archive:
    for file in sorted((BUILD/'dex').glob('*.dex')):
        archive.write(file, file.name)
    for file in sorted((APP/'assets').rglob('*')):
        if file.is_file():
            archive.write(file, 'assets/'+file.relative_to(APP/'assets').as_posix())
run([BT/('zipalign'+EXE), '-f', '4', BUILD/'base.apk', BUILD/'aligned.apk'])

release = bool(os.environ.get('SUISHOU_KEYSTORE'))
if release:
    KEY = Path(os.environ['SUISHOU_KEYSTORE']).expanduser().resolve()
    PASS = require_env('SUISHOU_PASSWORD_FILE')
    alias = os.environ.get('SUISHOU_KEY_ALIAS', 'suishou')
    if not KEY.is_file() or not PASS.is_file():
        raise SystemExit('Release keystore and password file must exist.')
else:
    KEY = BUILD/'signing/debug.p12'
    PASS = BUILD/'signing/password.txt'
    alias = 'androiddebugkey'
    if not PASS.exists():
        PASS.write_text('android\n', encoding='utf-8')
    if not KEY.exists():
        run([JAVA/('keytool'+EXE), '-genkeypair', '-keystore', KEY, '-storetype', 'PKCS12',
             '-storepass:file', PASS, '-alias', alias, '-keyalg', 'RSA', '-keysize', '2048',
             '-validity', '10000', '-dname', 'CN=Android Debug,O=Android,C=US'])
APK = BUILD/('Suishou-Ledger-release.apk' if release else 'Suishou-Ledger-debug.apk')
run([JAVA/('java'+EXE), '-jar', BT/'lib/apksigner.jar', 'sign', '--ks', KEY,
     '--ks-key-alias', alias, '--ks-pass', 'file:'+str(PASS), '--out', APK, BUILD/'aligned.apk'])
run([JAVA/('java'+EXE), '-jar', BT/'lib/apksigner.jar', 'verify', '--verbose', APK])
run([BT/('zipalign'+EXE), '-c', '4', APK])
print('Built and verified: '+str(APK))
