package com.suishou.ledger;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.AtomicFile;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class MainActivity extends Activity {
  private WebView web;
  private static final int EXPORT=101, IMPORT=102, MAX=25*1024*1024;
  private boolean choosing=false;
  private File pendingFile;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    pendingFile=new File(getFilesDir(),"pending-export.bin");
    web=new WebView(this);
    web.setBackgroundColor(0xfffbfcfb);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(false);
    web.getSettings().setAllowFileAccess(false);
    web.getSettings().setAllowContentAccess(false);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.getSettings().setSupportMultipleWindows(false);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){return true;}
      @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return true;}
    });
    web.addJavascriptInterface(new LedgerBridge(),"NativeLedger");
    setContentView(web);
    web.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets.consumeSystemWindowInsets();});
    web.loadUrl("file:///android_asset/index.html");
  }

  private void tell(String message){runOnUiThread(()->{if(!isFinishing())web.evaluateJavascript("toast("+JSONObject.quote(message)+")",null);});}
  private static byte[] limitedRead(InputStream in) throws IOException {
    if(in==null)throw new IOException("Cannot open file");
    try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buffer=new byte[8192];int count;
      while((count=stream.read(buffer))!=-1){if(out.size()+count>MAX)throw new IOException("File too large");out.write(buffer,0,count);}
      return out.toByteArray();
    }
  }

  private final class LedgerBridge {
    @JavascriptInterface public synchronized String read() {
      AtomicFile file=new AtomicFile(new File(getFilesDir(),"ledger.json"));
      try{return new String(limitedRead(file.openRead()),StandardCharsets.UTF_8);}
      catch(FileNotFoundException missing){return "";}
      catch(Exception error){return "READ_ERROR";}
    }
    @JavascriptInterface public synchronized boolean save(String data) {
      AtomicFile file=new AtomicFile(new File(getFilesDir(),"ledger.json"));FileOutputStream stream=null;
      try {
        JSONObject parsed=new JSONObject(data);
        if(!"suishou-ledger".equals(parsed.getString("app"))||parsed.getInt("version")!=1||parsed.getJSONArray("records").length()>100000)return false;
        byte[] bytes=data.getBytes(StandardCharsets.UTF_8);if(bytes.length>MAX)return false;
        stream=file.startWrite();stream.write(bytes);file.finishWrite(stream);return true;
      }catch(Exception error){if(stream!=null)file.failWrite(stream);return false;}
    }
    @JavascriptInterface public String newId(){return UUID.randomUUID().toString();}
    @JavascriptInterface public void exportFile(String content,String name,String mime) {
      runOnUiThread(()->{
        if(choosing){tell("请先完成当前文件选择");return;}
        try {
          byte[] bytes=content.getBytes(StandardCharsets.UTF_8);if(bytes.length>MAX)throw new IOException();
          try(FileOutputStream out=new FileOutputStream(pendingFile)){out.write(bytes);}
          Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
          intent.setType("text/csv;charset=utf-8".equals(mime)?"text/csv":"application/json");
          intent.putExtra(Intent.EXTRA_TITLE,name);choosing=true;startActivityForResult(intent,EXPORT);
        }catch(Exception error){choosing=false;pendingFile.delete();tell("无法打开保存窗口，请重试");}
      });
    }
    @JavascriptInterface public void importFile() {
      runOnUiThread(()->{
        if(choosing){tell("请先完成当前文件选择");return;}
        try{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");choosing=true;startActivityForResult(intent,IMPORT);}
        catch(Exception error){choosing=false;tell("无法打开文件选择，请重试");}
      });
    }
  }

  @Override protected void onActivityResult(int request,int result,Intent data) {
    super.onActivityResult(request,result,data);
    if(request!=EXPORT&&request!=IMPORT)return;
    choosing=false;
    if(result!=RESULT_OK||data==null||data.getData()==null){if(request==EXPORT)pendingFile.delete();tell("已取消");return;}
    final Uri uri=data.getData();
    if(request==EXPORT){
      new Thread(()->{try(InputStream in=new FileInputStream(pendingFile);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
        if(out==null)throw new IOException();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);out.flush();tell("已导出到选择的位置");
      }catch(Exception error){tell("导出失败，请重新选择保存位置");}finally{pendingFile.delete();}},"ledger-export").start();
    }else{
      new Thread(()->{try{String b64=Base64.encodeToString(limitedRead(getContentResolver().openInputStream(uri)),Base64.NO_WRAP);
        runOnUiThread(()->{if(!isFinishing())web.evaluateJavascript("receiveAndroidBackup("+JSONObject.quote(b64)+")",null);});
      }catch(Exception error){tell("无法读取备份，文件需小于 25 MB");}},"ledger-import").start();
    }
  }
  @Override public void onBackPressed(){web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(d){d.close();return 'closed';}return 'exit';})()",value->{if("\"exit\"".equals(value))super.onBackPressed();});}
  @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("NativeLedger");web.destroy();}super.onDestroy();}
}
