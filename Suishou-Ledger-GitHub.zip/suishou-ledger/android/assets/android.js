'use strict';
document.querySelector('.import-button').onclick=e=>{e.preventDefault();NativeLedger.importFile();};
window.receiveAndroidBackup=base64=>{
  try{
    const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));
    const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes).replace(/^\uFEFF/,'');
    const incoming=C.parseBackup(text);
    const known=new Set(records.map(r=>r.id));
    const added=incoming.filter(r=>!known.has(r.id));
    if(save([...records,...added]))toast(`已导入 ${added.length} 笔，跳过 ${incoming.length-added.length} 笔重复记录`);
  }catch(error){toast(error instanceof SyntaxError?'文件内容不是有效的 JSON 备份':error.message);}
};
