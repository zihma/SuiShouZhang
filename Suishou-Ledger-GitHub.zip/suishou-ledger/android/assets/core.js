(function(root){'use strict';
const categories={expense:['餐饮','购物','交通','居家','娱乐','医疗','学习','其他支出'],income:['工资','奖金','兼职','理财','红包','其他收入']};
function cents(value){const s=String(value).trim();if(!/^\d{1,9}(\.\d{1,2})?$/.test(s))throw Error('请输入大于 0 的金额，最多两位小数');const [a,b='']=s.split('.');const n=Number(a)*100+Number(b.padEnd(2,'0'));if(n<=0)throw Error('金额必须大于 0');return n;}
function validDate(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T12:00:00');return Number.isFinite(d.getTime())&&d.getFullYear()===Number(s.slice(0,4))&&d.getMonth()+1===Number(s.slice(5,7))&&d.getDate()===Number(s.slice(8,10));}
function validate(r){if(!r||typeof r!=='object'||typeof r.id!=='string'||!r.id||r.id.length>100||!categories[r.type]?.includes(r.category)||!Number.isSafeInteger(r.cents)||r.cents<=0||r.cents>99999999999||!validDate(r.date)||typeof r.note!=='string'||r.note.length>120)throw Error('备份中有无效记录，未导入任何数据');return {id:r.id,type:r.type,category:r.category,cents:r.cents,date:r.date,note:r.note};}
function parseBackup(text){const b=JSON.parse(text);if(b.app!=='suishou-ledger'||b.version!==1||!Array.isArray(b.records)||b.records.length>100000)throw Error('请选择随手账导出的完整 JSON 备份');const records=b.records.map(validate);if(new Set(records.map(r=>r.id)).size!==records.length)throw Error('备份包含重复编号，未导入任何数据');return records;}
function csv(records){const cell=v=>{let s=String(v);if(/^[\s]*[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};return '\uFEFF'+[['日期','类型','分类','金额（元）','备注'],...records.map(r=>[r.date,r.type==='income'?'收入':'支出',r.category,(r.cents/100).toFixed(2),r.note])].map(row=>row.map(cell).join(',')).join('\r\n');}
function totals(records){return records.reduce((t,r)=>(t[r.type]+=r.cents,t),{expense:0,income:0});}
root.LedgerCore={categories,cents,validDate,validate,parseBackup,csv,totals};if(typeof module!=='undefined')module.exports=root.LedgerCore;
})(typeof globalThis!=='undefined'?globalThis:this);
