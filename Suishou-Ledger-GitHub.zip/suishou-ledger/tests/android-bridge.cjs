const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const dir=__dirname+'/../android/assets/';
let data='',exported,importRequested=false,failSave=false;
class Element {
  constructor(){this.value='';this.textContent='';this.hidden=false;this._html='';this.classList={add(){},remove(){},toggle(){}};}
  set innerHTML(x){this._html=x;const option=x.match(/<option>([^<]+)/);if(option)this.value=option[1];}
  get innerHTML(){return this._html;}
  reset(){} focus(){} showModal(){this.open=true;} close(){this.open=false;}
}
const elements=new Map(),get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
get('filter').value='all';
const importLabel=new Element();
const ctx=vm.createContext({console,TextDecoder,Uint8Array,atob,setTimeout:()=>1,clearTimeout(){},navigator:{},document:{getElementById:get,querySelectorAll:()=>[],querySelector:()=>importLabel},window:{},NativeLedger:{read:()=>data,save:v=>{if(failSave)return false;data=v;return true;},newId:()=>require('node:crypto').randomUUID(),exportFile:(content,name,mime)=>{exported={content,name,mime};},importFile:()=>{importRequested=true;}}});
for(const file of ['core.js','app.js','android.js'])vm.runInContext(fs.readFileSync(dir+file,'utf8'),ctx);
function submit(amount,note='桥接功能测试'){get('amount').value=amount;get('note').value=note;get('entryForm').onsubmit({preventDefault(){}});}
get('add').onclick();submit('12.34');
assert.equal(JSON.parse(data).records[0].cents,1234);
assert.equal(get('expense').textContent,'¥12.34');
vm.runInContext("openEntry();setType('income')",ctx);submit('100.01');
assert.equal(get('balance').textContent,'¥87.67');
const id=JSON.parse(data).records[0].id;
vm.runInContext(`openEntry(${JSON.stringify(id)})`,ctx);submit('15.50');
assert.equal(JSON.parse(data).records.length,2);
assert.equal(JSON.parse(data).records[0].cents,1550);
const saved=data;
vm.runInContext('openEntry()',ctx);submit('0');assert.equal(data,saved);assert(get('formError').textContent);
failSave=true;submit('42');assert.equal(data,saved);assert.equal(get('entryDialog').open,true);failSave=false;
get('exportJson').onclick();assert.equal(exported.mime,'application/json');assert.equal(JSON.parse(exported.content).records.length,2);
let backup=JSON.parse(exported.content);backup.records.push({...backup.records[0],id:'imported-record',note:'导入记录',cents:99});
ctx.window.receiveAndroidBackup(Buffer.from(JSON.stringify(backup)).toString('base64'));
assert.equal(JSON.parse(data).records.length,3);
ctx.window.receiveAndroidBackup(Buffer.from(JSON.stringify(backup)).toString('base64'));
assert.equal(JSON.parse(data).records.length,3);
const afterImport=data;
ctx.window.receiveAndroidBackup(Buffer.from(JSON.stringify({...backup,records:[{...backup.records[0],cents:-1}]})).toString('base64'));
assert.equal(data,afterImport);
get('exportCsv').onclick();assert.equal(exported.mime,'text/csv;charset=utf-8');assert(exported.content.startsWith('\uFEFF'));assert(exported.content.includes('15.50'));
importLabel.onclick({preventDefault(){}});assert(importRequested);
assert.equal(JSON.parse(ctx.NativeLedger.read()).records.length,3);
console.log('PASS: native storage save/read, expense/income totals, edit, invalid amount, failed-save preservation, full export, import merge/deduplication, invalid-backup rejection, CSV export and native file-picker dispatch.');

